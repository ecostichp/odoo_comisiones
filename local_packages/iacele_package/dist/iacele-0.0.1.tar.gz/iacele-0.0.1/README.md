## IACele, inteligencia de negocios a tu alcance

Librería para crear BI en la administración de la empresa LA CASA DEL CARPINTERO. Esta capa de código es creada por el grupo de desarrollo administrativo <b>LOS ZOPILOTES:</b> Gretel, Pável y el Lic.